# ols가 제공하는 표에 대해 알아보기
import pandas as pd
import statsmodels.formula.api as smf   # 이게 ols 수행해주는 라이브러리
import numpy as np

df = pd.read_csv('https://raw.githubusercontent.com/pykwon/python/refs/heads/master/testdata_utf8/drinking_water.csv')
print(df.head(3))
print(df.corr())
# 결과창은 데이터간의 상관관계를 보여주는 정방행렬
# 데이터 자기자신은 당연히 자신이랑 관계가 크니까 대각원소값은 1.0

print('회귀분석 수행 -----------')
model = smf.ols(formula = '만족도 ~ 적절성', data = df).fit()  # 이게 최소제곱법을 수행해준대 .fit()
print(model.summary())
print('-' * 100)

print('parameters : ', model.params)
print('-' * 100)
print('R squared : ', model.rsquared)
print('-' * 100)
print('p-value : ', model.pvalues)
print('-' * 100)
# print('predicted value : ', model.predict())
print('-' * 100)
print('실제값 : \n', df.만족도,'\n예측값 : \n',model.predict()[0])   # 3.7359630488589186 
print('-' * 100)

# 이건 표 볼때만 주석 해제
# import matplotlib.pyplot as plt
# plt.rc('font', family = 'Malgun Gothic')
# plt.scatter(df.적절성, df.만족도)
# slope, intercept = np.polyfit(df.적절성, df.만족도, 1)
# plt.plot(df.적절성, df.적절성 * slope + intercept, 'b')
# plt.show()

#                             OLS Regression Results
# ==============================================================================
# Dep. Variable:                    만족도   R-squared:                       0.588
# Model:                            OLS   Adj. R-squared:                  0.586
# Method:                 Least Squares   F-statistic:                     374.0
# Date:                Fri, 22 Aug 2025   Prob (F-statistic):           2.24e-52
# Time:                        16:00:26   Log-Likelihood:                -207.44
# No. Observations:                 264   AIC:                             418.9
# Df Residuals:                     262   BIC:                             426.0
# Df Model:                           1
# Covariance Type:            nonrobust
# ==============================================================================
#                  coef    std err          t      P>|t|      [0.025      0.975]
# ------------------------------------------------------------------------------
# Intercept      0.7789      0.124      6.273      0.000       0.534       1.023
# 적절성            0.7393      0.038     19.340      0.000       0.664       0.815
# ==============================================================================
# Omnibus:                       11.674   Durbin-Watson:                   2.185
# Prob(Omnibus):                  0.003   Jarque-Bera (JB):               16.003
# Skew:                          -0.328   Prob(JB):                     0.000335
# Kurtosis:                       4.012   Cond. No.                         13.4
# ==============================================================================



# 여기부턴 결과창의 표 설명

# -------------------------------------------------------------------------------------

# R²(결정계수, 설명력) : 독립변수 x가 종속변수 y를 얼마나 설명하고 있느냐를 판단. 그래서 설명력이라고도 부름.
#                       1에 가까울수록 좋으나 1에 지나치게 가까워지면 기형모델일 수 있다.(오버피팅)

# 특정 데이터에게만 너무 최적화해서 학습시키면(그니까 R²값이 1과 거의 근사하게 설계한다면) 이 특정된 데이터에 한해서는
# 높은 정확도로 판별을 해내지만 비슷한 데이터에 대해서는 판별을 하지 못한다.
# 그니까 고양이사진만 주구장창 학습시켜서 오버피팅된 프로그램에 담요덮은 고양이사진을 판별시키면 고양이로 못알아본대
# 설명력이 너무 좋아도 우수한 프로그램이라 보지 않나봐

# Adj. R-squared:                  0.586
# 결과창에서 우상단의 이거 잇잖아 이거는 독립변수가 복수개일 때 사용하는 "수정된 R²"래
# 또 지피티가 변수 개수가 늘어날수록 R²값은 항상 증가하지만, 1에 가까워짐을 경계해야되고 과도한 변수 추가를 벌점처럼 반영한대



# ==============================================================================
#                  coef    std err          t      P>|t|      [0.025      0.975]
# ------------------------------------------------------------------------------
# Intercept      0.7789      0.124      6.273      0.000       0.534       1.023
# 적절성            0.7393      0.038     19.340      0.000       0.664       0.815

# 또 여기서 적절성 행의 데이터를 차례로 설명하면 0.7393(기울기값) 0.038(유의수준) 19.340(t값 : 두 집단 간의 평균의 차이)
# 그리고 t값 제곱하면 f값이래 이 f값을 이용해서 t-test와 f검정에 활용해 p-value를 구한다고 해



# Omnibus:                       11.674   Durbin-Watson:                   2.185
# Prob(Omnibus):                  0.003   Jarque-Bera (JB):               16.003
# Skew:                          -0.328   Prob(JB):                     0.000335
# Kurtosis:                       4.012   Cond. No.                         13.4
# ==============================================================================

# 여기서는 "Durbin-Watson" 값은 잔차의 독립성을 확인할 때 보는 수래 2에 근사하면 좋대(자기상관이 독립, 자기상관 없음)
# 그니까 잔차끼리 서로 영향을 주지 않고 랜덤하게 분포한다는 뜻

# Jarque-Bera (JB) 
# : 이거는 적합도 검정으로 왜도(왜곡된 정도)와 첨도(뾰족한 정도)가 정규분포로 보기에 적합한지 확인하는 값
# JB값은 양수만 존재하며 0에 가까울수록 정규분포에 가깝다

# Prob(JB) 
# : 오차의 정규성 가정을 검증. 0.05보다 작으면 정규성 실패 (유의수준이랑 비슷한 얘기네)

# Prob(Omnibus)
# : 0.05보다 작으면 유의하다. 회귀모형의 유의성 확인용.

# 표준오차에 대한 이야기